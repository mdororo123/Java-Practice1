public class SDPQ{
	public static void main(String[] args){
		//calculate the sum of two integers
		int a=2;
		int b=3;
		System.out.println(a+b);
		//calculate the difference between the two integers
		int c=8;
		int d=23;
		System.out.println(d-c);
		//calculate	the prodcut between two integers
		int e=4;
		int f=10;
		System.out.println(e*f);
		//calculate the quotient of two integers
		int g=5;
		int h=60;
		System.out.println(h/g);
		
	}

}