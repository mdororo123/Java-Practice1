//data types
//char char- used for single characters
//int,long,short,byte- this is integer types.
//float and double- this is for numbers that have a decimal like 25.5.by default float is stored as double
//boolean- this is used for yes or no programs(true and false);

public class section7dataTypes{
	public static void main(String[] args){
	char ch='A';
	double no=23.2d;
	String name="Mtho";
	boolean age=true;
	
	System.out.println("hello "+name+" Your age is: "+no+" You a male right? "+age);
	
	}
}