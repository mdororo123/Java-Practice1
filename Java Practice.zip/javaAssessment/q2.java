public class q2{
	public static void main(String[] args){
		int a = 5;
		int b = 2;
		
		
		// prints  7
		System.out.println(a + b);
		//prints 3
		System.out.println(a - b);
		//prints 10
		System.out.println(a * b);
		//prints 2
		System.out.println(a / b);
		//prints 1 because this is the remainder
		System.out.println(a % b);
	}
}