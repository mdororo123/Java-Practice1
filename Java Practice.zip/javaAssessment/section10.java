//section10
//escape sequence
//\t- that tab escape sequence. inserts a tab in a string
//\n- newline - inserts string in  new line
//\"- this is used to print inverted comma's something like "\Hello"\ 
//\\

public class section10{
	public static void main(String[] args){
	System.out.println("Hello \n Mtho Always\t do \"Good\"   ");
	
	}
}