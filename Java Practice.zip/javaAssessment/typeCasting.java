/*type casting
In implicit type casting, the programming language automatically converts data from one type to another if needed. For example, if you have an integer variable and you try to assign it 
to a float variable, the programming language will automatically convert the integer to a float without you having to do anything.
e.g -
int num_int = 10;
double num_double = num_int;  // Implicitly converts int to double


Explicit type casting, also known as type conversion or type coercion, occurs when the programmer explicitly converts a value from one data type to another. Unlike implicit type casting, 
explicit type casting requires the programmer to specify the desired data type conversion.
e.g -
double num_double = 10.5;
int num_int = (int)num_double;  // Explicitly casts double to int*/

public class typeCasting{
	public static void main(String[] args){
	//program that converts a double to an int using type casting
	
	double num_double = 10.5;
	int num_int = (int)num_double;  
	System.out.println(num_double);
	
	}
}



