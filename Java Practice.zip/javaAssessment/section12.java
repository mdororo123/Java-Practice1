//section12_Varargs
// varargs are what we pass values as arguments in a program, like strings,double,char.

public class secion12{
	public static void main(String[] args){
	int age=23;
	float height=5.8f;
	double legs = 2;
	String text= " And you learning to code";
	
	
	System.out.println("Hello Mtho "+ "You have "+legs+" legs " + " and your height is "+height+""+text);
	
	
	
	
	}
}