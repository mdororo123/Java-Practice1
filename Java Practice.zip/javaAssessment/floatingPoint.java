public class floatingPoint{
	public static void main(String[] args){
	double a= 11.5F;
	double b= 6.5F;
		if(a==b){
		System.out.println("a is not equal to b");
			}
		if(a<b){
		System.out.println("a is less than b");
		}
		if(a>b){
		System.out.println("b is greater than a");
		}
	}
}